"""privacy-label: Privacy nutrition label for any website. Scan, score, compare."""
__version__ = "0.2.0"
